import json
import boto3
import os
import random
import datetime
from datetime import date, datetime

s3 = boto3.client('s3')
S3Bucket = os.getenv('S3Bucket')

def lambda_handler (event, context):
    FileName = 'Export_' + datetime.now().strftime('%Y%m%d%H%M%S') + '_' + str(random.randint(0,1000)) + '.json'
    TmpFile = '/tmp/' + FileName
    S3File = 'ExportedData/data_year=' + datetime.now().strftime('%Y') + '/data_month=' + datetime.now().strftime('%m') + '/data_date=' + datetime.now().strftime('%d') + '/' + FileName
    cntr = 0
    TempFile = open(TmpFile,'a')
    for record in event['Records']:
        cntr += 1
        TempFile.write('{"Item":' + str(json.dumps(record['dynamodb']['OldImage'])) + '}')
        if cntr != len(event['Records']):
            TempFile.write('\n')
    TempFile.close()
    s3.upload_file(TmpFile,S3Bucket,S3File)
    print(S3File + ' file has been uploaded to ' + S3Bucket + ' bucket.')
    return "Success"
